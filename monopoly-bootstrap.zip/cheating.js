// cheating.js - build #2
// change log
// 1. set the time for focusing the password text box longer. 
// it doesn't work with shorter amounts of time. 


// a set of tools for intrepidcoder's original
// monopoly game.
// created november 23 2019 - just in time for thanksgiving!
function admintoolspassword(){
  $("#admintoolspass").modal();
  setTimeout(function(){$("#passinputbox").focus()},600)
};
$("#admintoolspasswordform").submit(function(event){
  if ($("#passinputbox").val() == "disismypassword78"){
    $("#passinputbox").val('')
    $("#admintoolspass").modal('hide');
    admintools();
  } else{
    popup("That is the incorrect password!")
  }
  event.preventDefault();
});
function admintools() {
  //open the password modal. (CHANGE: Helper function will call this function.)NOT IMPLEMENTED YET. REPLACE void(0)
  //GENERATE Modal contents dynamically. 
  genPlayers();
  genTiles();
  $("#admintoolsmodal").modal()

};
function chooseposfunc(playnum){
    //ADAPTED FROM CHOOSE OWNER FUNCTION. Leftovers might still be here. 
	$("#choosepostext").empty();
	$("#choosepostext").append("<p>Yellow shows which tile the player is currently on.</p><table class='table table-striped'><thead><tr><th scope='col'>Name</th><th scope='col'>Choose</th></tr></thead><tbody id='choosetexttbody'>")
	
	$.each(square, function(index,value){
		if (player[playnum]["position"] == index){
			$("#choosetexttbody").append("<tr><th scope='row'><p class='text-danger'>"+value["name"]+"</p></th><td><button class='btn btn-primary' onclick='setposvalue(" + index+"," +playnum+")'>Choose</button></td></tr>")
		} else{
		$("#choosetexttbody").append("<tr><th scope='row'><p>"+value["name"]+"</p></th><td><button class='btn btn-primary' onclick='setposvalue(" + index+"," +playnum+")'>Choose</button></td></tr>")}
	});
	$("#choosepostext").append("</tbody></table>")
	$("#chooseposmodal").modal();
};
function setposvalue(posval,playnum){
    $("#pos"+playnum).val(posval);
    $("#chooseposmodal").modal('hide')
};
function genTiles() {
  $("#tiles").empty();
  $("#tiles").append('<table class="table table-striped"><thead><tr><th scope="col">Name</th><th scope="col">Configure</th></tr></thead><tbody id="tilesbody">')
  $.each(square, function(index, value){
    $("#tilesbody").append("<tr><th scope='row'><p>"+value["name"]+"</p></th><td><button onclick='configureTile("+index+")' class='btn btn-primary'>Configure</button></tr>")
  })
  $("#tilesbody").append('</tbody></table>')
};
function configureTile(tilenum){
  $("#savetile").attr("onclick", "updatetiledata("+tilenum+");")
  $("#configuretilemodal").modal()
  populateconfiguremodal(tilenum);
};
function populateconfiguremodal(tilenum){
  $("#tileinfo").html("<b>Editing: "+square[tilenum]["name"]+"</b>")
  $("#baserent").val(square[tilenum]["baserent"])
  $("#pricetext").val(square[tilenum]["pricetext"])
  $("#hotel").val(square[tilenum]["hotel"])
  $("#house").val(square[tilenum]["house"])
  $("#houseprice").val(square[tilenum]["houseprice"])
  $("#owner").val(square[tilenum]["owner"])
  $("#price").val(square[tilenum]["price"])
  $("#rent1").val(square[tilenum]["rent1"])
  $("#rent2").val(square[tilenum]["rent2"])
  $("#rent3").val(square[tilenum]["rent2"])
  $("#rent4").val(square[tilenum]["rent4"])
  $("#rent5").val(square[tilenum]["rent5"])


};
function updatetiledata(tilenum){
  square[tilenum]["baserent"] = parseInt($("#baserent").val())
  square[tilenum]["hotel"] = parseInt($("#hotel").val())
  square[tilenum]["house"] = parseInt($("#house").val())
  square[tilenum]["houseprice"] = parseInt($("#houseprice").val())
  square[tilenum]["owner"] =parseInt( $("#owner").val())
  square[tilenum]["price"] = parseInt($("#price").val())
  square[tilenum]["rent1"] = parseInt($("#rent1").val())
  square[tilenum]["rent2"] = parseInt($("#rent2").val())
  square[tilenum]["rent2"] = parseInt( $("#rent3").val())
  square[tilenum]["rent4"] = parseInt($("#rent4").val())
  square[tilenum]["rent5"] = parseInt($("#rent5").val())
  square[tilenum]["pricetext"] = $("#pricetext").val()
  square[tilenum]["mortgage"] = $("#mortgaged").prop("checked");
};
function genPlayers() {
  $("#players").empty();
  $("#players").append('<button onclick="genPlayers();" class="btn btn-primary">Reset Data</button>')
  $("#players").append('<table class="table table-striped"><thead><tr><th scope="col">Name</th><th scope="col">Human?</th><th scope="col">Jailed?</th><th scope="col">Money</th><th scope="col">Position</th><th scope="col">Jail Roll</th><th scope="col">Jail card?</th><th scope="col">Eliminate</th></tr></thead><tbody id="playerstbody">')
  $.each(player, function(index, value){
    //gen players tab.
    $("#playerstbody").append("<tr><th scope='row'><input id='name" +index+ "' class='form-control'></th><td><div class='custom-control custom-checkbox'><input id='human"+ index+"' type='checkbox' class='custom-control-input'><label class='custom-control-label' for='human"+index+"'></label></div></td><td><div class='custom-control custom-checkbox'><input id='jailed"+ index+"' type='checkbox' class='custom-control-input'><label class='custom-control-label' for='jailed"+index+"'></label></div></td><td><input id='money"+index+"' class='form-control small-input'></td><td><input id='pos"+index+"' class='form-control small-input'><button onclick='chooseposfunc(" +index+")' class='btn btn-info'>Choose</button></td><td><input id='jailroll"+index+"' class='form-control small-input'></td><td><div class='custom-control custom-checkbox'><input id='jailcard"+ index+"' type='checkbox' class='custom-control-input'><label class='custom-control-label' for='jailcard"+index+"'>Chance</label></div><div class='custom-control custom-checkbox'><input id='jailcardcomm"+ index+"' type='checkbox' class='custom-control-input'><label class='custom-control-label' for='jailcardcomm"+index+"'>Comm Chest.</label></div></td><td><button class='btn btn-danger' onclick='forceFullyEliminatePlayer(" +index+ ")'>Eliminate</button></td></tr>")
    
  });
  $("#players").append('</tbody></table><button onclick="saveall();" class="btn btn-info" >Save</button>')
  populateDataPlayers();
};
function populateDataPlayers(){
  $.each(player, function (index,value){
    //populate name field
    $("#name"+index).val(value["name"]);
    $("#human"+index).prop("checked", value["human"]);
    $("#jailed"+index).prop("checked", value["jail"]);
    $("#money"+index).val(value["money"]);
    $("#pos"+index).val(value["position"]);
    $("#jailroll"+index).val(value["jailroll"]);
    $("#jailcard"+index).prop("checked", value["chanceJailCard"]);
    $("#jailcardcomm"+index).prop("checked", value["communityChestJailCard"])
    
  })
}
function updateEverything(){
  updateMoney(); updatePosition(); updateOwned(); 
};
function updateplayer(playernum){
  player[playernum]["name"] = $("#name"+playernum).val();
  player[playernum]["human"] = $("#human"+playernum).prop("checked");
  player[playernum]["jail"] = $("#jailed"+playernum).prop("checked");
  player[playernum]["money"] = parseInt($("#money"+playernum).val())
  player[playernum]["position"] = parseInt($("#pos"+playernum).val())
  player[playernum]["jailroll"] = parseInt($("#jailroll"+playernum).val())
  player[playernum]["chanceJailCard"] = $("#jailcard"+playernum).prop("checked");
  player[playernum]["communityChestJailCard"] = $("#jailcardcomm"+playernum).prop("checked");
  updateEverything();
};
function saveall(){
  $.each(player, function(index, value){
    updateplayer(index);
  })
};
function forceFullyEliminatePlayer(playernum){
	var p = player[playernum];
	$.each(square, function(index,value){
		if (value["owner"] == playernum){
			square[index]["owner"] = 0;
		}
	});
    for (var i = p.index; i < pcount; i++) {
      player[i] = player[i + 1];
      player[i].index = i;

    }

    for (var i = 0; i < 40; i++) {
      if (square[i].owner >= p.index) {
        square[i].owner--;
      }
    }

    pcount--;
    turn--;
    if (pcount === 1) {
      updateMoney();
      $("#control").hide();
      $("#board").hide();
      $("#refresh").show();

      // // Display land counts for survey purposes.
      // var text;
      // for (var i = 0; i < 40; i++) {
      // if (i === 0)
      // text = square[i].landcount;
      // else
      // text += " " + square[i].landcount;
      // }
      // document.getElementById("refresh").innerHTML += "<br><br><div><textarea type='text' style='width: 980px;' onclick='javascript:select();' />" + text + "</textarea></div>";

      popup("<p>Congratulations, " + player[1].name + ", you have won the game.</p><div>");

    } else {
      play();
    }
};
function chooseowner(){
	$("#ownertext").empty();
	$("#ownertext").append("<table class='table table-striped'><thead><tr><th scope='col'>Name</th><th scope='col'>Choose</th></tr></thead><tbody id='ownertexttbody'>")
	$.each(player, function(index,value){
		$("#ownertexttbody").append("<tr><th scope='row'><p>"+value["name"]+"</p></th><td><button class='btn btn-primary' onclick='setownervalue(" + index+")'>Choose</button></td></tr>")
	});
	$("#ownertext").append("</tbody></table>")
	$("#chooseownermodal").modal();
};
function setownervalue(ownernum){
	$("#owner").val(ownernum);
	$("#chooseownermodal").modal('hide');
};
function manipulatedices(){
	window.manipulatedice = true;
	window.mandie2 = parseInt($("#die2inputbox").val())
	window.mandie1 = parseInt($("#die1inputbox").val())
};
//features:
// name
// money
// human
// jail or unjail player
// jailroll
// position
